# Task: C ABI shim scaffold

- **Owner:** Nick + Clio
- **Status:** DONE
- **Goal:** Create strict C ABI shim boundary matching `docs/spec/v0-nucleus.h`.
- **Acceptance:**
  - exported symbol map draft
  - compileable shim stubs
  - status/error plumbing hooks


## Progress
- Added Rust `extern "C"` shim skeleton with strict status enum and context lifecycle fns.
- Added baseline constructor surface (`rtc_nil`, `rtc_bool`, `rtc_i64`, `rtc_f64`, `rtc_strn`) and value free helper.
- Copied frozen ABI draft header into `include/v0-nucleus.h` for alignment review.
- `rtc_get_ex`/`rtc_get_in_ex` wired to core ops.
- `rtc_nassoc_ex`/`rtc_nassoc_in_ex` wired to core ops.
- `rtc_nupdate_ex`/`rtc_nupdate_in_ex` wired to core ops.
- Added direct ABI surface integration tests (`tests/abi_surface.rs`).
- Added callback edge-case tests for update/update_in error paths.

## Closure evidence
- `cargo test --tests` passing on full suite.
