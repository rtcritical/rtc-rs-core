use crate::core::{self, rtc_status, Key, UpdaterFn, Value};

// Value constructors (Rust-to-Rust ergonomic layer)
pub fn nil() -> Value { Value::Nil }
pub fn b(v: bool) -> Value { Value::Bool(v) }
pub fn i(v: i64) -> Value { Value::I64(v) }
pub fn f(v: f64) -> Value { Value::F64(v) }
pub fn st<S: Into<String>>(v: S) -> Value { Value::Str(v.into()) }

pub fn v_from<I>(iter: I) -> Value
where
    I: IntoIterator<Item = Value>,
{
    Value::Vec(iter.into_iter().collect())
}

// set is extension-oriented in current model; represented as vector until set type lands
pub fn s_from<I>(iter: I) -> Value
where
    I: IntoIterator<Item = Value>,
{
    Value::Vec(iter.into_iter().collect())
}

pub fn m_from_pairs<K>(pairs: Vec<(K, Value)>) -> Value
where
    K: Into<String>,
{
    Value::Map(pairs.into_iter().map(|(k, v)| (k.into(), v)).collect())
}
// m_from builds map values from runtime iterables of key/value tuples.
// Prefer this for map/reduce/filter pipelines or decoded inputs.
pub fn m_from<I, K>(iter: I) -> Value
where
    I: IntoIterator<Item = (K, Value)>,
    K: Into<String>,
{
    m_from_pairs(iter.into_iter().collect())
}



pub fn vals<'a>(m: &'a [(String, Value)]) -> Vec<&'a Value> {
    m.iter().map(|(_, v)| v).collect()
}

pub fn keys<S: Into<String>>(s: S) -> Key { Key::Str(s.into()) }
pub fn idx(n: i64) -> Key { Key::Index(n) }

fn path_keys(path: &[&str]) -> Vec<Key> {
    path.iter().map(|s| keys(*s)).collect()
}

pub fn get_in(root: &Value, path: &[&str]) -> Result<Value, rtc_status> {
    core::get_in(root, &path_keys(path))
}

pub fn nassoc_in(root: &Value, path: &[&str], val: Value) -> Result<Value, rtc_status> {
    core::assoc_in(root, &path_keys(path), val)
}

pub fn nupdate_in(root: &Value, path: &[&str], f: UpdaterFn) -> Result<Value, rtc_status> {
    core::update_in(root, &path_keys(path), f)
}


// Mutable single-key ops (explicit n* convention)
pub fn nassoc(root: &Value, key: &Key, val: Value) -> Result<Value, rtc_status> {
    core::assoc(root, key, val)
}

pub fn nupdate(root: &Value, key: &Key, f: UpdaterFn) -> Result<Value, rtc_status> {
    core::update(root, key, f)
}
